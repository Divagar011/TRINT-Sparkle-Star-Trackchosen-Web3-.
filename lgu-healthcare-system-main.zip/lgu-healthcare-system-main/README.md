# lgu-healthcare-system
a web application used by LGU health workers to check health consumable supplies, free medicines and checkup appointments by the barangay residents!

![image](https://github.com/jvfaeldon20/lgu-healthcare-system/assets/61104555/bc2cf4ce-a637-4b54-8eeb-79e3efcc6820)
![image](https://github.com/jvfaeldon20/lgu-healthcare-system/assets/61104555/bb4ba1de-664c-4604-bed5-b0fa5b1c8a0f)
![image](https://github.com/jvfaeldon20/lgu-healthcare-system/assets/61104555/9ea831a5-b815-48d7-8477-a31835459845)
![image](https://github.com/jvfaeldon20/lgu-healthcare-system/assets/61104555/ece10ef4-36c0-4d8e-94fa-2c862c6a9d49)
![image](https://github.com/jvfaeldon20/lgu-healthcare-system/assets/61104555/ea84d245-9a22-4025-87b7-c98a9b21cfd5)
![image](https://github.com/jvfaeldon20/lgu-healthcare-system/assets/61104555/40b76ce3-1540-4515-bad4-4f7aba17e82f)

